package com.example.contentmanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    MainDashboardScreen()
                }
            }
        }
    }
}

data class ChannelItem(val id: Int, val name: String, val status: String, val subscribers: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainDashboardScreen() {
    var selectedTab by remember { mutableStateOf(0) }
    val channels = remember {
        mutableStateOf(
            listOf(
                ChannelItem(1, "xYer6Haber", "Active (Bot Sync)", "45.2K"),
                ChannelItem(2, "Sansürsüz Dünya", "Publishing", "12.8K"),
                ChannelItem(3, "xsporgundemi", "Monitoring", "34.1K"),
                ChannelItem(4, "Turkuaz Ads", "Connected", "9.5K")
            )
        )
    }
    Scaffold(
        topBar = { TopAppBar(title = { Text("ContentHub Pro - Modern Manager") }) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(icon = { Icon(Icons.Default.Home, null) }, label = { Text("Dashboard") }, selected = selectedTab == 0, onClick = { selectedTab = 0 })
                NavigationBarItem(icon = { Icon(Icons.Default.List, null) }, label = { Text("Bots") }, selected = selectedTab == 1, onClick = { selectedTab = 1 })
                NavigationBarItem(icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Settings") }, selected = selectedTab == 2, onClick = { selectedTab = 2 })
            }
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            when (selectedTab) {
                0 -> {
                    Text("Managed Channels & Feeds", style = MaterialTheme.typography.titleLarge)
                    Spacer(modifier = Modifier.height(12.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(channels.value) { channel ->
                            Card(modifier = Modifier.fillMaxWidth()) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text(text = channel.name, style = MaterialTheme.typography.titleMedium)
                                    Text(text = "Status: ${channel.status}", style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }
                    }
                }
                1 -> {
                    Text("Automation & Bot Management", style = MaterialTheme.typography.titleLarge)
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("Sync All Telegram & RSS Feeds") }
                }
                2 -> {
                    Text("System Settings", style = MaterialTheme.typography.titleLarge)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Version: 2.0.0")
                }
            }
        }
    }
}
